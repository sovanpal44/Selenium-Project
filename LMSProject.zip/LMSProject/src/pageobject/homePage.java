package pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import testbase.base;

public class homePage extends base {
	private static WebElement element = null;
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public String title(WebDriver driver) {

		return driver.getTitle();

	}

	public WebElement pageheading(WebDriver driver) {

		element = driver.findElement(By.xpath(".//*[@class='uagb-ifb-title']"));
		return element;
	}

	public WebElement firstinfoBox(WebDriver driver) throws AWTException {

		element = driver.findElement(By.xpath(".//*[contains(text(),'Actionable Training')]"));
		return element;
	}

	public WebElement emailmarketing(WebDriver driver) throws AWTException {

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);

		element = driver.findElement(By.xpath(".//*[@id=\"post-71\"]/div[2]/h3"));
		return element;

	}

}
