package pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import testbase.base;
import utility.constant;

public class myAccount extends base {
	WebElement element;

	public void clickmyAccount(WebDriver driver) {

		driver.findElement(By.xpath(".//*[contains(text(),'My Account')]")).click();

	}

	public String myaccounttitle(WebDriver driver) {

		return driver.getTitle();

	}

	public void clicklogin(WebDriver driver) {

		driver.findElement(By.xpath(".//*[contains(text(),'Login')]")).click();
	}

	public void usernamepassword(WebDriver driver) {

		driver.switchTo().activeElement();
		driver.findElement(By.xpath(".//*[@id='user_login']")).sendKeys(constant.Username);
		driver.findElement(By.xpath(".//*[@id='user_pass']")).sendKeys(constant.password);
		driver.findElement(By.xpath(".//*[@value='Log In']")).click();

	}

	public String loginpage(WebDriver driver) {

		return driver.getTitle();
	}

	public void allCOurse(WebDriver driver) {

		driver.findElement(By.xpath(".//*[@id='post-69']")).click();
	}

	public void clickcourse(WebDriver driver) {

		driver.findElement(By.xpath(".//*[@class='btn btn-primary']")).click();
	}

	public void findcourses(WebDriver driver) {

		element = driver.findElement(By.xpath(".//*[@id=\"ld-course-list-content-2f03b97ab51efe00449b53a93c07fbeb\"]/div"));
		System.out.println("Number of courses :" + element.findElements(By.className("ld_course_grid")).size());
	}

	public void clickaccount(WebDriver driver) {

		driver.findElement(By.xpath(".//*[contains(text(),'Contact')]")).click();
	}

	public void enteraccountdetails(WebDriver driver) throws AWTException {

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);

		driver.findElement(By.xpath(".//*[@id='wpforms-8-field_0']")).sendKeys(constant.FullName);
		driver.findElement(By.xpath(".//*[@type='email']")).sendKeys(constant.Email);
		driver.findElement(By.xpath(".//*[@id='wpforms-8-field_3']")).sendKeys(constant.Subject);
		driver.findElement(By.xpath(".//*[@name='wpforms[fields][2]']")).sendKeys(constant.Comment);

		driver.findElement(By.xpath(".//*[@type='submit']")).click();
	}

	public void message(WebDriver driver) {

		WebElement element = driver.findElement(By.xpath(".//*[@id='wpforms-confirmation-8']"));
		System.out.println("Displayed message :" + element.getText());

	}

	public void enroll(WebDriver driver) throws AWTException {

//		Robot robot = new Robot();
//		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
//		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);

		driver.findElement(By.xpath(".//*[@id=\"learndash_post_69\"]/div/div[1]/div[3]/div/div/a")).click();
		usernamepassword(driver);
	}

	public void selectlesson(WebDriver driver) throws AWTException, InterruptedException {

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
		Thread.sleep(4000);

		driver.findElement(By.xpath(".//*[@class=\"ld-expand-button ld-primary-background\"]")).click();

	}

	public void markComplete(WebDriver driver) throws AWTException, InterruptedException {

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
		Thread.sleep(4000);

		driver.findElement(By.xpath(".//*[@class=\"ld-status-icon ld-status-incomplete\"]")).click();

		Robot robot1 = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);

		driver.findElement(By.xpath(".//*[@type='submit']")).click();

	}

}
