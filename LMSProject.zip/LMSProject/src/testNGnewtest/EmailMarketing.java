package testNGnewtest;

import java.awt.AWTException;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.homePage;
import testbase.base;
import utility.constant;

public class EmailMarketing extends base {
	@Test
	public void f() throws AWTException {

		homePage homePageobj = new homePage();
		WebElement emailmarketingtxt = homePageobj.emailmarketing(driver);
		System.out.println("The text is  :" + emailmarketingtxt.getText());
		Assert.assertEquals(emailmarketingtxt.getText(), constant.emailMarketing);

	}

	@BeforeTest
	public void beforeTest() {
		openbrowser();
	}

	@AfterTest
	public void afterTest() {

		closebrowser();
	}

}
