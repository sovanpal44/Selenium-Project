package testNGnewtest;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.homePage;
import testbase.base;
import utility.constant;

public class LmsTitle extends base {

	homePage homePageObj = new homePage();

	@Test
	public void titleverify() {

		String pageTitle1 = homePageObj.title(driver);

		Assert.assertEquals(pageTitle1, constant.PageTitle);

	}

	@BeforeTest
	public void beforeTest() {

		openbrowser();

	}

	@AfterTest
	public void afterTest() {

		closebrowser();
	}

}
