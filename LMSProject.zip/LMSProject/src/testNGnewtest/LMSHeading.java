package testNGnewtest;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.homePage;
import testbase.base;
import utility.constant;

public class LMSHeading extends base {
	@Test
	public void headingVerify() {

		homePage homePageobj = new homePage();
		WebElement pageheading1 = homePageobj.pageheading(driver);
		Assert.assertEquals(pageheading1.getText(), constant.heading);

	}

	@BeforeTest
	public void beforeTest() {

		openbrowser();

	}

	@AfterTest
	public void afterTest() {

		closebrowser();
	}

}
