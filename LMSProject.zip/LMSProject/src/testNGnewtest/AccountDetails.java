package testNGnewtest;

import java.awt.AWTException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.myAccount;
import testbase.base;

public class AccountDetails extends base {
	@Test
	public void account() throws AWTException {

		myAccount myAccountobj = new myAccount();
		myAccountobj.clickaccount(driver);
		myAccountobj.enteraccountdetails(driver);
		myAccountobj.message(driver);
	}

	@BeforeTest
	public void beforeTest() {

		openbrowser();
	}

	@AfterTest
	public void afterTest() {
		closebrowser();
	}

}
