package testNGnewtest;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.myAccount;
import testbase.base;
import utility.constant;

public class verifyMyaccount extends base {
	@Test
	public void myaccount() {

		myAccount myAccountobj = new myAccount();
		myAccountobj.clickmyAccount(driver);
		String pageTitle1 = myAccountobj.myaccounttitle(driver);
		Assert.assertEquals(pageTitle1, constant.myAccounttitle);

	}

	@BeforeTest
	public void beforeTest() {

		openbrowser();
	}

	@AfterTest
	public void afterTest() {

		closebrowser();
	}

}
