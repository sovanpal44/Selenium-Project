package testNGnewtest;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.myAccount;
import testbase.base;

public class AllCourses extends base {
	@Test
	public void f() {

		myAccount myAccountobj = new myAccount();
		myAccountobj.allCOurse(driver);
		myAccountobj.findcourses(driver);
	}

	@BeforeTest
	public void beforeTest() {
		openbrowser();
	}

	@AfterTest
	public void afterTest() {

		closebrowser();
	}

}
