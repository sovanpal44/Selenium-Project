package testNGnewtest;

import java.awt.AWTException;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.homePage;
import testbase.base;
import utility.constant;

public class firstInfoBox extends base {
	@Test
	public void f() throws AWTException {

		homePage homePageobj = new homePage();
		WebElement pageheading = homePageobj.firstinfoBox(driver);
		Assert.assertEquals(pageheading.getText(), constant.infobox);

	}

	@BeforeTest
	public void beforeClass() {

		openbrowser();
	}

	@AfterTest
	public void afterTest() {

		closebrowser();
	}

}
