package testNGnewtest;

import java.awt.AWTException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobject.myAccount;
import testbase.base;

public class markCompletelesson extends base {
	@Test
	public void markcomplete() throws AWTException, InterruptedException {

		myAccount myAccountobj = new myAccount();
		myAccountobj.allCOurse(driver);
		myAccountobj.clickcourse(driver);
		Thread.sleep(5000);
		myAccountobj.enroll(driver);
		myAccountobj.selectlesson(driver);
		myAccountobj.markComplete(driver);

	}

	@BeforeTest
	public void beforeTest() {

		openbrowser();
	}

	@AfterTest
	public void afterTest() {

		closebrowser();
	}

}
