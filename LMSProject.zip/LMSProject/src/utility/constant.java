package utility;

public class constant {

	public static final String URL = "https://alchemy.hguy.co/lms";
	public static final String Username = "root";
	public static final String password = "pa$$w0rd";
	public static final String PageTitle = "Alchemy LMS – An LMS Application";
	public static final String heading = "Learn from Industry Experts";
	public static final String infobox = "Actionable Training";
	public static final String emailMarketing = "Email Marketing Strategies";
	public static final String myAccounttitle = "My Account – Alchemy LMS";
	public static final String FullName = "Sovan Kumar Pal";
	public static final String Email = "sovanpal@in.ibm.com";
	public static final String Subject = "Test";
	public static final String Comment = "test12";

}
