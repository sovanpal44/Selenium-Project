package testbase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utility.constant;

public class base {

	protected WebDriver driver;

	public void openbrowser() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(constant.URL);
		driver.manage().window().maximize();

	}

	public void closebrowser() {

		driver.close();
	}

}
